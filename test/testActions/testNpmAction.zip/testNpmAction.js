function main(params) {
  return {
    value: {
      "action": "testNpmAction",
      params
    }
  }
}
exports.main = main;